import React, { useState, useEffect } from 'react';
import { Routes, Route, Link, useParams } from 'react-router-dom';
import { supabase } from './lib/supabase';
import { Calendar, CreditCard, Heart, Star, Users } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import toast from 'react-hot-toast';
import { format } from 'date-fns';

interface Service {
  id: number;
  name: string;
  slug: string;
  description: string;
  benefits: string;
  price: number;
  duration: number;
  image_url: string;
}

interface Practitioner {
  id: number;
  name: string;
  bio: string;
  image_url: string;
}

interface Testimonial {
  id: number;
  service_id: number;
  name: string;
  rating: number;
  comment: string;
}

interface Booking {
  id: number;
  appointment_time: string;
  status: string;
  credits_used: number;
  services: { name: string };
  practitioners: { name: string };
}

interface JournalEntry {
  id: number;
  entry_date: string;
  mood: number;
  energy: number;
  notes: string;
}

interface Profile {
  credits: number;
  membership_tier: string | null;
  membership_expires: string | null;
}


function Navbar({ user, onLogin, onLogout }: { user: any; onLogin: () => void; onLogout: () => void }) {
  return (
    <nav className="bg-white border-b sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-6 py-5 flex justify-between items-center">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-emerald-600 rounded-full flex items-center justify-center">
            <Heart className="w-6 h-6 text-white" />
          </div>
          <div>
            <div className="font-semibold text-2xl tracking-tight">BlissNow</div>
            <div className="text-xs text-emerald-600 -mt-1">HOLISTIC HEALTH</div>
          </div>
        </div>

        <div className="flex items-center gap-8 text-sm font-medium">
          <Link to="/" className="hover:text-emerald-600 transition-colors">Home</Link>
          <Link to="/services" className="hover:text-emerald-600 transition-colors">Services</Link>
          <Link to="/membership" className="hover:text-emerald-600 transition-colors">Membership</Link>
          {user && <Link to="/dashboard" className="hover:text-emerald-600 transition-colors">Dashboard</Link>}
          <button 
            onClick={user ? onLogout : onLogin}
            className="px-6 py-2.5 bg-emerald-600 text-white rounded-full hover:bg-emerald-700 transition-all flex items-center gap-2 text-sm"
          >
            {user ? 'Sign Out' : 'Sign In'}
          </button>
        </div>
      </div>
    </nav>
  );
}

function AuthModal({ isOpen, onClose, isSignup, setIsSignup }: { isOpen: boolean; onClose: () => void; isSignup: boolean; setIsSignup: (b: boolean) => void }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      if (isSignup) {
        const { error } = await supabase.auth.signUp({ email, password });
        if (error) throw error;
        toast.success('Check your email to confirm account');
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        toast.success('Signed in successfully');
      }
      onClose();
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-[100] p-4">
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="bg-white rounded-3xl p-10 w-full max-w-md"
          >
            <div className="text-center mb-8">
              <div className="mx-auto w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mb-4">
                <Heart className="w-8 h-8 text-emerald-600" />
              </div>
              <h2 className="text-3xl font-semibold">{isSignup ? 'Create Account' : 'Welcome Back'}</h2>
              <p className="text-gray-500 mt-2">Sign in to book sessions and manage your wellness</p>
            </div>

            <form onSubmit={handleAuth} className="space-y-5">
              <div>
                <label className="block text-sm mb-1.5 text-gray-600">Email</label>
                <input 
                  type="email" 
                  value={email} 
                  onChange={(e) => setEmail(e.target.value)} 
                  className="w-full px-5 py-3.5 border rounded-2xl focus:outline-none focus:border-emerald-500" 
                  placeholder="you@email.com" 
                  required 
                />
              </div>
              <div>
                <label className="block text-sm mb-1.5 text-gray-600">Password</label>
                <input 
                  type="password" 
                  value={password} 
                  onChange={(e) => setPassword(e.target.value)} 
                  className="w-full px-5 py-3.5 border rounded-2xl focus:outline-none focus:border-emerald-500" 
                  placeholder="••••••••" 
                  required 
                />
              </div>
              <button 
                type="submit" 
                disabled={loading}
                className="w-full py-4 bg-emerald-600 hover:bg-emerald-700 text-white rounded-2xl font-medium transition-all disabled:opacity-70"
              >
                {loading ? 'Processing...' : isSignup ? 'Create Account' : 'Sign In'}
              </button>
            </form>

            <div className="my-6 flex items-center gap-3 text-sm">
              <div className="flex-1 h-px bg-gray-200"></div>
              <div className="text-gray-400">OR</div>
              <div className="flex-1 h-px bg-gray-200"></div>
            </div>

            <button 
              onClick={() => toast('Google Sign-In coming soon')}
              className="w-full py-4 border border-gray-300 hover:bg-gray-50 rounded-2xl flex items-center justify-center gap-3 font-medium"
            >
              <img src="https://www.google.com/favicon.ico" className="w-5 h-5" alt="Google" /> Continue with Google
            </button>

            <div className="text-center mt-6 text-sm">
              {isSignup ? (
                <>Already have an account? <button onClick={() => setIsSignup(false)} className="text-emerald-600 underline">Sign in</button></>
              ) : (
                <>Don't have an account? <button onClick={() => setIsSignup(true)} className="text-emerald-600 underline">Sign up</button></>
              )}
            </div>

            <button onClick={onClose} className="absolute top-6 right-6 text-gray-400 hover:text-gray-600">✕</button>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}

function ServiceDetail() {
  const { slug } = useParams<{ slug: string }>();
  const [service, setService] = useState<Service | null>(null);
  const [practitioners, setPractitioners] = useState<Practitioner[]>([]);
  const [testimonials, setTestimonials] = useState<Testimonial[]>([]);
  const [showBookingModal, setShowBookingModal] = useState(false);
  const [selectedPractitioner, setSelectedPractitioner] = useState<number | null>(null);
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedTime, setSelectedTime] = useState('');
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    const fetchData = async () => {
      const { data: s } = await fetch(`/api/services`).then(r => r.json());
      const found = s.find((sv: Service) => sv.slug === slug);
      setService(found);

      const { data: t } = await fetch(`/api/testimonials?service_id=${found?.id}`).then(r => r.json());
      setTestimonials(t || []);

      const { data: p } = await fetch(`/api/practitioners`).then(r => r.json());
      setPractitioners(p || []);
    };
    fetchData();

    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
    });
  }, [slug]);

  const handleBook = async () => {
    if (!user || !selectedPractitioner || !selectedDate || !selectedTime || !service) {
      toast.error('Please select all fields and be logged in');
      return;
    }

    const appointmentTime = new Date(`${selectedDate}T${selectedTime}`).toISOString();
    const creditsUsed = Math.ceil(service.price / 15); // example

    try {
      const res = await fetch('/api/bookings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          user_id: user.id,
          practitioner_id: selectedPractitioner,
          service_id: service.id,
          appointment_time: appointmentTime,
          credits_used: creditsUsed
        })
      });

      if (res.ok) {
        toast.success('Booking confirmed! Confirmation sent to email.');
        setShowBookingModal(false);
        // Refresh profile etc
      } else {
        const err = await res.json();
        toast.error(err.error || 'Booking failed');
      }
    } catch (e) {
      toast.error('Failed to book');
    }
  };

  const timeSlots = ['09:00', '10:00', '11:30', '14:00', '15:30', '16:45', '18:00'];

  if (!service) return <div className="p-20 text-center">Loading...</div>;

  return (
    <div className="max-w-5xl mx-auto px-6 py-12">
      <div className="flex justify-between items-start mb-12">
        <div>
          <div className="uppercase tracking-[3px] text-xs text-emerald-600 mb-3">EXPERT CARE</div>
          <h1 className="text-6xl font-semibold tracking-tighter">{service.name}</h1>
        </div>
        <div className="text-right">
          <div className="text-5xl font-semibold text-emerald-600">${service.price}</div>
          <div className="text-sm text-gray-500">per {service.duration} min session</div>
        </div>
      </div>

      <img src={service.image_url} alt={service.name} className="w-full h-[480px] object-cover rounded-3xl mb-12" />

      <div className="grid md:grid-cols-2 gap-12">
        <div>
          <h3 className="font-semibold text-xl mb-4">About this service</h3>
          <p className="text-lg leading-relaxed text-gray-600">{service.description}</p>
          
          <h3 className="font-semibold text-xl mt-12 mb-4">Key Benefits</h3>
          <ul className="space-y-3">
            {service.benefits.split('. ').filter(Boolean).map((b, i) => (
              <li key={i} className="flex gap-3 text-gray-600">
                <div className="mt-1.5 w-2 h-2 rounded-full bg-emerald-500 flex-shrink-0"></div>
                {b}
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h3 className="font-semibold text-xl mb-4">Our Practitioners</h3>
          <div className="space-y-6">
            {practitioners.slice(0, 3).map((p, idx) => (
              <div key={idx} className="flex gap-5 border-b pb-6 last:border-none">
                <img src={p.image_url} alt="" className="w-20 h-20 rounded-2xl object-cover" />
                <div>
                  <div className="font-medium">{p.name}</div>
                  <div className="text-sm text-gray-500 mt-1 line-clamp-3">{p.bio}</div>
                  <button 
                    onClick={() => { setSelectedPractitioner(p.id); setShowBookingModal(true); }}
                    className="mt-4 text-xs uppercase tracking-widest border border-emerald-600 px-5 py-2 rounded-full hover:bg-emerald-50"
                  >
                    Book with {p.name.split(' ')[0]}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="mt-16">
        <h3 className="font-semibold text-xl mb-8">Patient Stories</h3>
        <div className="grid md:grid-cols-2 gap-6">
          {testimonials.map((t, i) => (
            <div key={i} className="bg-white border p-8 rounded-3xl">
              <div className="flex mb-6">
                {Array.from({ length: t.rating }).map((_, k) => <Star key={k} className="w-5 h-5 text-amber-400" />)}
              </div>
              <p className="italic text-lg">“{t.comment}”</p>
              <div className="mt-8 text-sm font-medium">{t.name}</div>
            </div>
          ))}
        </div>
      </div>

      <div className="mt-16 flex justify-center">
        <button 
          onClick={() => setShowBookingModal(true)}
          className="px-14 py-4 bg-black text-white rounded-full text-lg flex items-center gap-3 hover:bg-zinc-800 transition"
        >
          Book Your Session <Calendar className="w-5 h-5" />
        </button>
      </div>

      {/* Booking Modal */}
      <AnimatePresence>
        {showBookingModal && (
          <div className="fixed inset-0 bg-black/80 z-[200] flex items-center justify-center p-6">
            <motion.div initial={{opacity:0, y:20}} animate={{opacity:1, y:0}} className="bg-white rounded-3xl max-w-lg w-full overflow-hidden">
              <div className="p-10">
                <h3 className="text-3xl font-semibold mb-2">Book {service.name}</h3>
                <p className="text-gray-500">Select practitioner, date and time</p>

                <div className="mt-8">
                  <label className="block text-sm mb-3">Practitioner</label>
                  <select 
                    value={selectedPractitioner || ''} 
                    onChange={(e) => setSelectedPractitioner(parseInt(e.target.value))}
                    className="w-full p-4 border rounded-2xl"
                  >
                    <option value="">Select practitioner</option>
                    {practitioners.map(p => (
                      <option key={p.id} value={p.id}>{p.name}</option>
                    ))}
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-6 mt-6">
                  <div>
                    <label className="block text-sm mb-3">Date</label>
                    <input 
                      type="date" 
                      value={selectedDate} 
                      onChange={(e) => setSelectedDate(e.target.value)}
                      min={format(new Date(), 'yyyy-MM-dd')}
                      className="w-full p-4 border rounded-2xl" 
                    />
                  </div>
                  <div>
                    <label className="block text-sm mb-3">Time</label>
                    <select 
                      value={selectedTime} 
                      onChange={(e) => setSelectedTime(e.target.value)}
                      className="w-full p-4 border rounded-2xl"
                    >
                      <option value="">Select time</option>
                      {timeSlots.map(t => (
                        <option key={t} value={t}>{t}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="mt-10 flex gap-4">
                  <button onClick={() => setShowBookingModal(false)} className="flex-1 py-4 border rounded-2xl">Cancel</button>
                  <button onClick={handleBook} className="flex-1 py-4 bg-emerald-600 text-white rounded-2xl">Confirm Booking</button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

function Membership() {
  const [credits, setCredits] = useState(10);
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setUser(data.session?.user));
  }, []);

  const getPricePerCredit = (qty: number) => {
    if (qty <= 5) return 12;
    if (qty <= 15) return 11;
    if (qty <= 25) return 10;
    return 9;
  };

  const totalPrice = Math.round(credits * getPricePerCredit(credits));

  const handlePurchaseCredits = async () => {
    if (!user) {
      toast.error('Please sign in first');
      return;
    }
    try {
      const res = await fetch('/api/create-checkout', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ user_id: user.id, type: 'credits', credits })
      });
      const { url } = await res.json();
      if (url) window.location.href = url;
    } catch (e) {
      toast.error('Payment setup failed');
    }
  };

  const tiers = [
    { name: 'Essentials', price: 49, credits: 8, color: 'emerald' },
    { name: 'Wellness', price: 89, credits: 15, color: 'teal' },
    { name: 'Premium', price: 149, credits: 30, color: 'violet' },
    { name: 'Unlimited', price: 249, credits: 999, color: 'rose' },
  ];

  return (
    <div className="max-w-5xl mx-auto px-6 py-20">
      <div className="text-center mb-16">
        <div className="inline-flex items-center gap-2 px-4 py-1 bg-emerald-100 text-emerald-700 rounded-full text-sm mb-4">MEMBERSHIPS</div>
        <h1 className="text-6xl font-semibold tracking-tighter">Choose your path to wellness</h1>
        <p className="max-w-md mx-auto mt-6 text-lg text-gray-600">Flexible plans with credits that roll over every 30 days</p>
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        {/* Build Your Own */}
        <div className="border border-gray-200 rounded-3xl p-12">
          <h2 className="text-4xl font-semibold mb-4">Build Your Own</h2>
          <p className="text-gray-500">Select the number of credits you need</p>

          <div className="my-12">
            <div className="flex justify-between text-sm mb-4 font-medium">
              <div>CREDITS</div>
              <div className="text-4xl font-semibold text-emerald-600">{credits}</div>
            </div>
            <input 
              type="range" 
              min="2" 
              max="30" 
              step="1" 
              value={credits} 
              onChange={(e) => setCredits(parseInt(e.target.value))} 
              className="w-full accent-emerald-600" 
            />
            <div className="flex justify-between text-xs text-gray-400 mt-1">
              <div>2</div><div>30</div>
            </div>
          </div>

          <div className="flex items-baseline gap-2 mb-10">
            <div className="text-6xl font-semibold">${totalPrice}</div>
            <div className="text-gray-500">one-time</div>
          </div>

          <button 
            onClick={handlePurchaseCredits}
            className="w-full py-5 bg-black text-white rounded-2xl font-medium text-lg active:scale-[0.985]"
          >
            Purchase {credits} Credits
          </button>
          <div className="text-xs text-center mt-4 text-gray-400">Volume discounts applied automatically</div>
        </div>

        {/* Tiers */}
        <div>
          {tiers.map((tier, index) => (
            <div key={index} className="border border-gray-200 rounded-3xl p-9 mb-5 last:mb-0 group hover:border-emerald-200 transition-all">
              <div className="flex justify-between">
                <div>
                  <div className="uppercase text-xs tracking-[2px] text-emerald-600">{tier.name}</div>
                  <div className="text-6xl font-semibold mt-3">${tier.price}</div>
                  <div className="text-sm text-gray-500">per month</div>
                </div>
                <div className="text-right self-end">
                  <div className="text-emerald-600 text-xl font-medium">{tier.credits} credits/mo</div>
                </div>
              </div>
              <button 
                onClick={async () => {
                  if (!user) return toast.error('Sign in to subscribe');
                  const res = await fetch('/api/create-checkout', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ user_id: user.id, type: 'membership', tier: tier.name })
                  });
                  const { url } = await res.json();
                  if (url) window.location.href = url;
                }}
                className="mt-10 w-full py-4 text-sm tracking-widest border-2 border-black hover:bg-black hover:text-white rounded-2xl transition-all"
              >
                SUBSCRIBE
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function Dashboard() {
  const [user, setUser] = useState<any>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [journals, setJournals] = useState<JournalEntry[]>([]);
  const [newJournal, setNewJournal] = useState({ mood: 3, energy: 3, notes: '' });
  const [activeTab, setActiveTab] = useState<'upcoming' | 'history' | 'journal'>('upcoming');

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      const u = session?.user;
      setUser(u);
      if (u) {
        fetchProfile(u.id);
        fetchBookings(u.id);
        fetchJournals(u.id);
      }
    });

    const { data: listener } = supabase.auth.onAuthStateChange((_, session) => {
      setUser(session?.user ?? null);
    });

    return () => listener.subscription.unsubscribe();
  }, []);

  const fetchProfile = async (uid: string) => {
    const res = await fetch(`/api/profiles?user_id=${uid}`);
    const data = await res.json();
    setProfile(data);
  };

  const fetchBookings = async (uid: string) => {
    const res = await fetch(`/api/bookings?user_id=${uid}`);
    const data = await res.json();
    setBookings(data || []);
  };

  const fetchJournals = async (uid: string) => {
    const res = await fetch(`/api/journals?user_id=${uid}`);
    const data = await res.json();
    setJournals(data || []);
  };

  const saveJournal = async () => {
    if (!user) return;
    const res = await fetch('/api/journals', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ user_id: user.id, ...newJournal })
    });
    if (res.ok) {
      toast.success('Journal entry saved');
      fetchJournals(user.id);
      setNewJournal({ mood: 3, energy: 3, notes: '' });
    }
  };

  const cancelBooking = async (id: number) => {
    if (!user) return;
    await fetch('/api/bookings', {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id })
    });
    toast.success('Booking cancelled');
    fetchBookings(user.id);
  };

  if (!user) {
    return <div className="text-center py-32">Please sign in to view dashboard</div>;
  }

  return (
    <div className="max-w-5xl mx-auto px-6 py-12">
      <div className="flex justify-between items-end mb-12">
        <div>
          <div className="text-emerald-600">WELCOME BACK</div>
          <div className="text-6xl font-semibold tracking-tight">Your Wellness Hub</div>
        </div>
        <div className="text-right">
          <div className="text-6xl font-semibold text-emerald-600">{profile?.credits || 0}</div>
          <div className="text-sm -mt-1">CREDITS REMAINING</div>
          {profile?.membership_tier && <div className="text-xs mt-2 uppercase tracking-widest bg-emerald-100 px-3 py-1 inline-block rounded-full">{profile.membership_tier}</div>}
        </div>
      </div>

      <div className="flex border-b mb-8">
        {(['upcoming', 'history', 'journal'] as const).map(tab => (
          <button 
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-8 pb-4 text-sm font-medium capitalize transition-all ${activeTab === tab ? 'border-b-2 border-emerald-600 text-emerald-600' : 'text-gray-500'}`}
          >
            {tab}
          </button>
        ))}
      </div>

      {activeTab === 'upcoming' && (
        <div>
          {bookings.length > 0 ? (
            bookings.filter(b => new Date(b.appointment_time) > new Date()).map((b, i) => (
              <div key={i} className="flex justify-between items-center border p-6 rounded-3xl mb-4">
                <div>
                  <div className="font-medium">{b.services?.name}</div>
                  <div className="text-sm text-gray-500">{b.practitioners?.name} • {format(new Date(b.appointment_time), 'PPP p')}</div>
                </div>
                <button onClick={() => cancelBooking(b.id)} className="text-red-600 text-sm">Cancel</button>
              </div>
            ))
          ) : <div className="opacity-60">No upcoming appointments</div>}
        </div>
      )}

      {activeTab === 'history' && (
        <div className="opacity-70">
          {bookings.filter(b => new Date(b.appointment_time) < new Date()).length === 0 && 'No past bookings yet.'}
          {/* similar list */}
        </div>
      )}

      {activeTab === 'journal' && (
        <div>
          <div className="bg-white border rounded-3xl p-10 mb-8">
            <h3 className="font-semibold mb-6">How are you feeling today?</h3>
            <div className="grid grid-cols-2 gap-8">
              <div>
                <div className="text-sm mb-3">MOOD</div>
                <div className="flex gap-4">
                  {[1,2,3,4,5].map(n => (
                    <button key={n} onClick={() => setNewJournal({...newJournal, mood: n})} className={`w-12 h-12 rounded-2xl flex items-center justify-center text-2xl transition-all ${newJournal.mood === n ? 'bg-amber-100 scale-110' : 'hover:bg-gray-100'}`}>{['😢','🙁','😐','🙂','😊'][n-1]}</button>
                  ))}
                </div>
              </div>
              <div>
                <div className="text-sm mb-3">ENERGY</div>
                <div className="flex gap-4">
                  {[1,2,3,4,5].map(n => (
                    <button key={n} onClick={() => setNewJournal({...newJournal, energy: n})} className={`w-12 h-12 rounded-2xl flex items-center justify-center text-2xl transition-all ${newJournal.energy === n ? 'bg-sky-100 scale-110' : 'hover:bg-gray-100'}`}>{n}</button>
                  ))}
                </div>
              </div>
            </div>
            <textarea 
              value={newJournal.notes} 
              onChange={e => setNewJournal({...newJournal, notes: e.target.value})} 
              className="mt-8 w-full h-28 border rounded-2xl p-6" 
              placeholder="Any reflections or notes for today..." 
            />
            <button onClick={saveJournal} className="mt-6 px-9 py-3.5 bg-black text-white rounded-2xl">Save Entry</button>
          </div>

          <div className="space-y-4">
            {journals.map((j, idx) => (
              <div key={idx} className="border rounded-3xl p-8">
                <div className="flex items-center justify-between mb-6">
                  <div className="font-mono text-xs text-gray-400">{j.entry_date}</div>
                  <div className="flex gap-6">
                    <div>Mood: {['😢','🙁','😐','🙂','😊'][j.mood-1]}</div>
                    <div>Energy: {j.energy}/5</div>
                  </div>
                </div>
                {j.notes && <p>{j.notes}</p>}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function Home() {
  const [services, setServices] = useState<Service[]>([]);
  const [testimonials, setTestimonials] = useState<Testimonial[]>([]);

  useEffect(() => {
    fetch('/api/services').then(r => r.json()).then(setServices);
    fetch('/api/testimonials').then(r => r.json()).then(setTestimonials);
  }, []);

  const pricingCalcTiers = [
    { name: 'Essentials', mo: 49, desc: '8 credits/mo' },
    { name: 'Wellness', mo: 89, desc: '15 credits/mo' },
    { name: 'Premium', mo: 149, desc: '30 credits/mo' }
  ];

  return (
    <div>
      {/* HERO */}
      <div className="relative h-screen flex items-center justify-center overflow-hidden bg-zinc-950 text-white">
        <div className="absolute inset-0 bg-[radial-gradient(#ffffff10_1px,transparent_1px)] bg-[length:4px_4px]"></div>
        <div className="relative z-10 text-center px-6 max-w-4xl">
          <div className="uppercase tracking-[4px] text-xs mb-6 text-emerald-400">EST. 2018 • NYC</div>
          <h1 className="text-7xl md:text-8xl font-semibold tracking-tighter leading-none mb-6">Rediscover<br />Your Balance</h1>
          <p className="max-w-md mx-auto text-xl text-gray-400">Premium holistic health experiences. Book today and begin your transformation.</p>
          <div className="flex justify-center gap-4 mt-12">
            <Link to="/services" className="px-10 py-5 bg-white text-black rounded-full font-medium inline-flex items-center gap-3">Explore Services</Link>
            <Link to="/membership" className="px-10 py-5 border border-white/40 hover:bg-white/10 rounded-full font-medium">View Memberships</Link>
          </div>
        </div>
        <div className="absolute bottom-12 left-1/2 -translate-x-1/2 flex flex-col items-center text-xs tracking-widest">SCROLL TO BEGIN</div>
      </div>

      {/* SERVICES GRID */}
      <div className="max-w-7xl mx-auto px-6 py-24">
        <div className="flex justify-between items-end mb-12">
          <div>
            <div className="uppercase text-xs tracking-widest text-emerald-600">OUR OFFERINGS</div>
            <h2 className="text-5xl font-semibold tracking-tight">Signature Experiences</h2>
          </div>
          <Link to="/services" className="text-sm flex items-center gap-2 hover:text-emerald-600">All Services →</Link>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, index) => (
            <Link to={`/services/${service.slug}`} key={index} className="group">
              <div className="overflow-hidden rounded-3xl border aspect-video relative">
                <img src={service.image_url} className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
                <div className="absolute inset-0 bg-gradient-to-b from-black/40 to-black/70"></div>
                <div className="absolute bottom-0 p-8 text-white">
                  <div className="font-semibold text-3xl tracking-tight">{service.name}</div>
                  <div className="text-xs mt-3 opacity-70">FROM ${service.price}</div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>

      {/* HOW IT WORKS */}
      <div className="bg-zinc-950 py-24 text-white">
        <div className="max-w-4xl mx-auto px-6">
          <div className="uppercase text-xs tracking-[4px] mb-4 text-emerald-500">PROCESS</div>
          <h2 className="text-6xl font-semibold tracking-tighter mb-16">Your journey begins in<br />three simple steps</h2>
          
          <div className="grid md:grid-cols-3 gap-12">
            {[
              { icon: <Users className="w-9 h-9" />, title: "Choose Practitioner", desc: "Browse expert profiles and read reviews." },
              { icon: <Calendar className="w-9 h-9" />, title: "Book Instantly", desc: "Select convenient dates and times." },
              { icon: <CreditCard className="w-9 h-9" />, title: "Arrive Restored", desc: "Use your credits or membership for seamless payment." }
            ].map((step, idx) => (
              <div key={idx} className="text-center">
                <div className="inline-block p-5 bg-white/10 rounded-3xl mb-8">{step.icon}</div>
                <div className="text-2xl font-medium mb-3">{step.title}</div>
                <p className="text-gray-400">{step.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* PRICING CALCULATOR */}
      <div className="max-w-4xl mx-auto px-6 py-24">
        <div className="text-center mb-12">
          <div className="text-emerald-600 font-medium tracking-widest">CALCULATOR</div>
          <h3 className="text-5xl font-semibold tracking-tighter mt-3">How much will it cost?</h3>
        </div>
        
        <div className="bg-white border p-12 rounded-3xl">
          <div className="flex flex-wrap gap-x-12 gap-y-8 justify-center">
            {pricingCalcTiers.map((t, i) => (
              <div key={i} className="text-center min-w-[180px]">
                <div className="text-6xl font-semibold text-emerald-600 mb-1">${t.mo}</div>
                <div className="text-xl font-medium mb-1">{t.name}</div>
                <div className="text-xs text-gray-500">{t.desc}</div>
              </div>
            ))}
          </div>
          <div className="h-px bg-gray-200 my-10"></div>
          <p className="text-center text-sm text-gray-500">Credits roll over monthly. Upgrade anytime.</p>
        </div>
      </div>

      {/* TESTIMONIALS CAROUSEL */}
      <div className="py-20 bg-zinc-50">
        <div className="max-w-4xl mx-auto px-6">
          <div className="text-center mb-12">
            <div className="text-xs tracking-widest text-emerald-600">TESTIMONIALS</div>
            <h3 className="text-5xl font-semibold tracking-tighter">Real transformations</h3>
          </div>
          <div className="flex flex-col md:flex-row gap-6">
            {testimonials.slice(0, 3).map((t, i) => (
              <div key={i} className="flex-1 bg-white p-9 rounded-3xl border">
                <div className="flex text-amber-400 mb-8">{'★'.repeat(t.rating)}</div>
                <p className="text-[15px] leading-snug">“{t.comment}”</p>
                <div className="mt-8 text-xs font-medium">— {t.name}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* PRACTITIONER SPOTLIGHT */}
      <div className="max-w-5xl mx-auto px-6 py-24">
        <div className="flex justify-between mb-8">
          <div>
            <div className="text-emerald-600 text-xs tracking-widest">MEET OUR TEAM</div>
            <h3 className="font-semibold text-5xl tracking-tighter">Practitioner Spotlight</h3>
          </div>
          <Link to="/services" className="self-end text-sm">Browse All →</Link>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            { name: "Dr. Elena Voss", role: "Physiotherapy Lead", img: "https://picsum.photos/id/64/600/400" },
            { name: "Dr. Sophia Patel", role: "Naturopathic Doctor", img: "https://picsum.photos/id/66/600/400" },
            { name: "Elena Moreau", role: "Mindfulness Coach", img: "https://picsum.photos/id/69/600/400" }
          ].map((p, idx) => (
            <div key={idx} className="rounded-3xl overflow-hidden border group">
              <img src={p.img} alt="" className="w-full h-72 object-cover group-hover:scale-105 transition" />
              <div className="p-8">
                <div className="font-semibold text-xl">{p.name}</div>
                <div className="text-sm text-emerald-600">{p.role}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* FINAL CTA */}
      <div className="bg-black text-white py-24 text-center">
        <div className="max-w-xl mx-auto px-6">
          <div className="text-emerald-500 tracking-[3px] text-sm mb-6">START TODAY</div>
          <div className="text-6xl font-semibold tracking-tighter leading-none">Your health transformation<br />is one decision away</div>
          <Link to="/membership" className="mt-10 inline-block px-12 py-4 bg-white text-black rounded-full text-lg">Join BlissNow</Link>
        </div>
      </div>
    </div>
  );
}

function ServicesPage() {
  const [services, setServices] = useState<Service[]>([]);

  useEffect(() => {
    fetch('/api/services').then(res => res.json()).then(setServices);
  }, []);

  return (
    <div className="max-w-6xl mx-auto px-6 py-20">
      <div className="mb-16 text-center">
        <div className="uppercase tracking-[4px] text-emerald-600 text-sm">DISCOVER</div>
        <h1 className="text-7xl tracking-tighter font-semibold">Our Services</h1>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-12">
        {services.map(s => (
          <Link key={s.id} to={`/services/${s.slug}`} className="group flex gap-7 border-b pb-12 last:border-none">
            <img src={s.image_url} className="w-52 h-52 object-cover rounded-3xl" />
            <div className="flex-1 pt-2">
              <div className="font-semibold text-4xl tracking-tight group-hover:text-emerald-600 transition-colors">{s.name}</div>
              <div className="mt-6 text-xl text-gray-600 leading-snug line-clamp-3">{s.description}</div>
              <div className="mt-auto pt-8 text-sm flex items-center gap-2 text-emerald-600">BOOK SESSION →</div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}

export default function App() {
  const [user, setUser] = useState<any>(null);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [isSignup, setIsSignup] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
    });

    return () => subscription.unsubscribe();
  }, []);

  const handleLogout = async () => {
    await supabase.auth.signOut();
    toast.success('Signed out');
  };

  return (
    <div className="min-h-screen bg-white font-sans">
      <Navbar user={user} onLogin={() => setShowAuthModal(true)} onLogout={handleLogout} />

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/services" element={<ServicesPage />} />
        <Route path="/services/:slug" element={<ServiceDetail />} />
        <Route path="/membership" element={<Membership />} />
        <Route path="/dashboard" element={<Dashboard />} />
      </Routes>

      <AuthModal 
        isOpen={showAuthModal} 
        onClose={() => setShowAuthModal(false)} 
        isSignup={isSignup} 
        setIsSignup={setIsSignup} 
      />

      <footer className="bg-zinc-950 text-white/70 py-20 text-sm">
        <div className="max-w-7xl mx-auto px-6 grid md:grid-cols-4 gap-y-12">
          <div>
            <div className="text-white text-xl font-medium mb-4">BlissNow</div>
            <div>© {new Date().getFullYear()} All rights reserved.</div>
          </div>
          <div className="md:col-span-3 grid grid-cols-3 gap-6 text-xs">
            <div>Services</div>
            <div>Our Story</div>
            <div>Journal</div>
            <div>Practitioners</div>
            <div>Contact Us</div>
            <div>Press</div>
          </div>
        </div>
      </footer>
    </div>
  );
}

